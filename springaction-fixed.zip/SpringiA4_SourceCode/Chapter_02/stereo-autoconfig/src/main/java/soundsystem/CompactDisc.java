package soundsystem;

public interface CompactDisc {
  void play();
}

package soundsystem;

public interface MediaPlayer {

  void play();

}
